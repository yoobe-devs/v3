export default function CriarKitPage() {
  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-6">Criar Kit</h1>
      <p>Crie kits personalizados de produtos.</p>
    </div>
  )
}

