export default function PrivacidadePage() {
  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-6">Política de Privacidade</h1>
      <p>Leia nossa política de privacidade.</p>
    </div>
  )
}

