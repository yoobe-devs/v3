export default function TermosPage() {
  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-6">Termos de Uso</h1>
      <p>Leia nossos termos de uso.</p>
    </div>
  )
}

