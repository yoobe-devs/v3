export default function ContatoPage() {
  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-6">Contato</h1>
      <p>Entre em contato conosco.</p>
    </div>
  )
}

