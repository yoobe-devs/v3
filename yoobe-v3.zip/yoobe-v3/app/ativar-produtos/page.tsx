export default function AtivarProdutosPage() {
  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-6">Ativar Produtos</h1>
      <p>Ative novos produtos para sua loja.</p>
    </div>
  )
}

