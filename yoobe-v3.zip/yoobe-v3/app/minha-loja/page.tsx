export default function MinhaLojaPage() {
  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-6">Minha Loja</h1>
      <p>Configure e gerencie sua loja online.</p>
    </div>
  )
}

