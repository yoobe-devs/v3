export default function SwagTrackPage() {
  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-6">Swag Track</h1>
      <p>Acompanhe e analise o desempenho do seu swag.</p>
    </div>
  )
}

