export default function ConfiguracoesPage() {
  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-6">Configurações</h1>
      <p>Ajuste as configurações da sua conta e plataforma.</p>
    </div>
  )
}

