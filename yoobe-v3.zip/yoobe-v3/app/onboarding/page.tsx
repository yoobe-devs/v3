export default function OnboardingPage() {
  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-6">Onboarding</h1>
      <p>Configure o processo de onboarding para novos usuários.</p>
    </div>
  )
}

