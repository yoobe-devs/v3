import { PedidosClient } from './pedidos-client'

export default function PedidosPage() {
  return <PedidosClient />
}

