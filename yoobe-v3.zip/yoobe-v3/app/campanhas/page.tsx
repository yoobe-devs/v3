export default function CampanhasPage() {
  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-6">Minhas Campanhas</h1>
      <p>Gerencie suas campanhas de marketing.</p>
    </div>
  )
}

